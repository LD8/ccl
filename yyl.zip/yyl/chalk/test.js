let chalk = require('chalk')

console.log(chalk.red('文字变红了'))
console.log(chalk.green('zce绿了'))
console.log(chalk.bgGreen('zce还是绿了'))