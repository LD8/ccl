// console.log(process.env)

// console.log(process.platform)  // 利用这个值可以判断当前是什么操作系统 win32

// console.log(process.env['USERPROFILE'])  // 使用  USERPROFILE 来获取管理员的路径目录

// if (process.platform == 'win32') {
//   console.log(process.env['USERPROFILE'])
// } else {
//   console.log(process.env['HOME'])
// }

// console.log(`${process.env[process.platform == 'win32' ? 'USERPROFILE' : 'HOME']}/.tmp`)

// let fs = require('fs')
// let path = require('path')

// console.log(__dirname)

// let a = fs.existsSync(path.join(__dirname, 'test.js1'))

// console.log(a)


'package-lock.json': {
  contents: <Buffer 7b 0a 20 20 22 6e 61 6d 65 22 3a 20 22 68 65 6c 6c 6f 31 22 2c 0a 20 20 22 76 65 72 73 69 6f 6e 22 3a 20 22 30 2e 31 2e 30 22 2c 0a 20 20 22 6c 6f 63 ... 482073 more bytes>,
  mode: '0666',
  stats: Stats {
    dev: 2992857361,
    mode: 33206,
    nlink: 1,
    uid: 0,
    gid: 0,
    rdev: 0,
    blksize: 4096,
    ino: 11821949021890680,
    size: 482123,
    blocks: 944,
    atimeMs: 1600577005804,
    mtimeMs: 1600293756000,
    ctimeMs: 1600577005839.1682,
    birthtimeMs: 1600577005835.1768,
    atime: 2020-09-20T04:43:25.804Z,
    mtime: 2020-09-16T22:02:36.000Z,
    ctime: 2020-09-20T04:43:25.839Z,
    birthtime: 2020-09-20T04:43:25.835Z
  }
},