let inquirer = require('inquirer')
let chalk = require('chalk')

async function fn () {
  let {key} = await inquirer.prompt({
    type: 'input', 
    message: '请输入密码',
    name: 'key',
    default: chalk.red(1233), 
  })
  console.log(key)

  // 使用 caz zce-cli 交互里的一些默认信息都是 zce 
}
fn()

// console.log(ret)